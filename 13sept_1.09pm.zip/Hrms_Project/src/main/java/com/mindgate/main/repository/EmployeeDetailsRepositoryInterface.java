package com.mindgate.main.repository;

import java.util.List;

import com.mindgate.main.domain.EmployeeDetails;

public interface EmployeeDetailsRepositoryInterface {

	public EmployeeDetails getEmployeeByLoginId(int loginId);

	public List<EmployeeDetails> checkEmployee(int jobId);
	
	public boolean updateJobStatus(EmployeeDetails employeeDetails);
	
	public boolean addEmployee(EmployeeDetails employeeDetails);
	
	public List<EmployeeDetails> getAllEmployee();

}
