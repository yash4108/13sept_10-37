package com.mindgate.main.repository;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;
import com.mindgate.main.domain.ApplicantDetails;
import com.mindgate.main.domain.DocumentDetails;
import com.mindgate.main.domain.JobDescriptionDetails;

public class ApplicantDetailsRowMapper implements RowMapper<ApplicantDetails> {

	@Override
	public ApplicantDetails mapRow(ResultSet rs, int rowNum)throws SQLException
	{
		
	
	    int applicantId = rs.getInt("APPLICANT_ID") ;
	    String  applicantName = rs.getString("APPLICANT_NAME") ;
	    String  qualification = rs.getString("QUALIFICATION") ;
	    String  skill1 = rs.getString("SKILL_1") ;
	    String  skill2 = rs.getString("SKILL_2") ;
	    String  skill3 = rs.getString("SKILL_3") ;
		int  contact = rs.getInt("CONTACT") ;
		int  documentId = rs.getInt("DOCUMENT_ID") ;	
		DocumentDetails documentDetails=new DocumentDetails();
		documentDetails.setDocumentId(documentId);
		JobDescriptionDetails jobDescriptionDetails=new JobDescriptionDetails();
		jobDescriptionDetails.setJobId(rs.getInt("JOB_ID"));		
ApplicantDetails applicantDetails=new ApplicantDetails(applicantId, applicantName, qualification, skill1, skill2, skill3, contact, documentDetails, jobDescriptionDetails);		  
		return applicantDetails;
	}
}
