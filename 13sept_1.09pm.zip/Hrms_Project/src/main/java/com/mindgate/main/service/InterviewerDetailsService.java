package com.mindgate.main.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindgate.main.domain.ApplicantDetails;
import com.mindgate.main.domain.InterviewerDetails;
import com.mindgate.main.repository.InterviewerDetailsRepositoryInterface;

@Service
public class InterviewerDetailsService implements InterviewerDetailsServiceInterface {

	@Autowired
    private InterviewerDetailsRepositoryInterface interviewerDetailsRepository;

	@Override
	public boolean addInterviewerDetails(InterviewerDetails interviewerDetails) {
		// TODO Auto-generated method stub
		return interviewerDetailsRepository.addInterviewerDetails(interviewerDetails);
	}

	@Override
	public List<InterviewerDetails> getInterviewerDetailst(int applicantId) {
		// TODO Auto-generated method stub
		return interviewerDetailsRepository.getInterviewerDetailst(applicantId);
	}

	@Override
	public boolean updateInterviewerDetails(InterviewerDetails interviewerDetails) {
		// TODO Auto-generated method stub
		return interviewerDetailsRepository.updateInterviewerDetails(interviewerDetails);
	}

	
}