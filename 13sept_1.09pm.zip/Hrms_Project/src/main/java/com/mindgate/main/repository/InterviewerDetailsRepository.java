package com.mindgate.main.repository;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.mindgate.main.domain.InterviewerDetails;

@Repository
public class InterviewerDetailsRepository implements InterviewerDetailsRepositoryInterface {

	private final static String INSERT_INTERVIWER_DETAILS = "insert into interviewer_details values(interviewer_table_sequence_series.NEXTVAL,?,?,?,?,?,?)";
	private final static String GET_INTERVIWER_DETAILS = "select interview_id,applicant_id,employee_id, status,round_1,round_2,round_3 from interviewer_details where applicant_id=?";           
	private final static String PUT_INTERVIWER_DETAILS ="UPDATE interviewer_details SET status = ?, round_1 =?,round_2 = ?,round_3=?  WHERE  applicant_id = ?";
	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public boolean addInterviewerDetails(InterviewerDetails interviewerDetails) {
		// TODO Auto-generated method stub
		Object[] param = { interviewerDetails.getApplicantDetails().getApplicantId(),
				interviewerDetails.getEmployeeDetails().getEmployeeId(),interviewerDetails.getStatus(), interviewerDetails.getRound1(), interviewerDetails.getRound2(),
				interviewerDetails.getRound3() };
		int result = jdbcTemplate.update(INSERT_INTERVIWER_DETAILS, param);
		if (result > 0) {
			System.out.println("insert success");
			return true;
		}
		return false;
	}

	@Override
	public List<InterviewerDetails> getInterviewerDetailst(int applicantId) {
		return jdbcTemplate.query(GET_INTERVIWER_DETAILS, new InterviewerDetailsRowMapper(), applicantId);

	}

	@Override
	public boolean updateInterviewerDetails(InterviewerDetails interviewerDetails) {
		// TODO Auto-generated method stub
		int result= jdbcTemplate.update(PUT_INTERVIWER_DETAILS, new InterviewerDetailsRowMapper(),interviewerDetails.getStatus(),interviewerDetails.getRound1(),interviewerDetails.getRound2(),interviewerDetails.getRound3(),interviewerDetails.getApplicantDetails().getApplicantId());
		if (result>0)
			return true;
		return false;
		}
}

